/**
 * MAIN.JS — Orchestrateur de l'application
 * Branche les événements UI aux appels API.
 * Import : api.js (HTTP) + state.js (état) + ui.js (rendu)
 */

import { Auth, register, login, logout, openBooster, getInventory } from "./api.js";
import { setState, getState, subscribe } from "./state.js";
import {
  renderAuthView,
  renderDashboardView,
  renderBoosterOpeningView,
  renderInventoryView,
  showError,
} from "./ui.js";

// --- Point de montage ---
const app = document.getElementById("app");

// =========================================================
// ROUTEUR DE VUES
// =========================================================

/**
 * Navigue vers une vue et met à jour l'état.
 * @param {"auth"|"dashboard"|"booster"|"inventory"} view
 * @param {object} [data] - Données optionnelles à passer à la vue
 */
function navigate(view, data = {}) {
  setState({ currentView: view });

  const { currentUser, lastDrawnCard } = getState();

  switch (view) {
    case "auth":
      renderAuthView(app);
      bindAuthEvents();
      break;

    case "dashboard":
      renderDashboardView(app, currentUser);
      bindDashboardEvents();
      break;

    case "booster":
      renderBoosterOpeningView(app, data);
      bindBoosterEvents();
      break;

    case "inventory":
      renderInventoryView(app, data);
      bindInventoryEvents();
      break;
  }
}

// =========================================================
// INITIALISATION
// =========================================================

async function init() {
  // Si un token existe, on considère l'utilisateur connecté
  // (dans une vraie app, on vérifierait le token auprès du serveur)
  if (Auth.isLoggedIn()) {
    const savedUser = JSON.parse(localStorage.getItem("ac_user") || "null");
    if (savedUser) {
      setState({ currentUser: savedUser });
      navigate("dashboard");
      return;
    }
  }
  navigate("auth");
}

// =========================================================
// ÉVÉNEMENTS : VUE AUTH
// =========================================================

function bindAuthEvents() {
  const form = document.getElementById("auth-form");
  const tabs = document.querySelectorAll(".tab-btn");
  let currentTab = "login";

  // Gestion des onglets Connexion / Inscription
  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      tabs.forEach((t) => t.classList.remove("active"));
      tab.classList.add("active");
      currentTab = tab.dataset.tab;

      const submitBtn = document.getElementById("auth-submit-btn");
      submitBtn.textContent =
        currentTab === "login" ? "Se connecter" : "Créer mon compte";
    });
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value;
    const submitBtn = document.getElementById("auth-submit-btn");

    submitBtn.disabled = true;
    submitBtn.textContent = "Chargement...";

    try {
      let result;

      if (currentTab === "login") {
        result = await login(username, password);
      } else {
        result = await register(username, password);
      }

      // Sauvegarde de l'utilisateur en localStorage (cache léger)
      localStorage.setItem("ac_user", JSON.stringify(result.user));
      setState({ currentUser: result.user });

      // Si c'est un nouveau compte et que le tutoriel n'a pas encore été fait
      if (!result.user.hasSeenTutorial) {
        await handleFirstBooster();
      } else {
        navigate("dashboard");
      }
    } catch (err) {
      showError(err.message);
      submitBtn.disabled = false;
      submitBtn.textContent =
        currentTab === "login" ? "Se connecter" : "Créer mon compte";
    }
  });
}

// =========================================================
// ÉVÉNEMENTS : VUE DASHBOARD
// =========================================================

function bindDashboardEvents() {
  document.getElementById("btn-open-booster").addEventListener("click", handleOpenBooster);
  document.getElementById("btn-view-inventory").addEventListener("click", handleViewInventory);
  document.getElementById("btn-logout").addEventListener("click", handleLogout);
}

// =========================================================
// ÉVÉNEMENTS : VUE BOOSTER
// =========================================================

function bindBoosterEvents() {
  document.getElementById("btn-back-dashboard").addEventListener("click", () => {
    navigate("dashboard");
  });
}

// =========================================================
// ÉVÉNEMENTS : VUE INVENTAIRE
// =========================================================

function bindInventoryEvents() {
  document.getElementById("btn-back-dashboard").addEventListener("click", () => {
    navigate("dashboard");
  });
}

// =========================================================
// ACTIONS MÉTIER
// =========================================================

/**
 * Ouvre le premier booster (tutoriel — appelé automatiquement après l'inscription).
 */
async function handleFirstBooster() {
  try {
    const result = await openBooster();

    // Mise à jour de l'utilisateur en mémoire + localStorage
    localStorage.setItem("ac_user", JSON.stringify(result.user));
    setState({ currentUser: result.user, lastDrawnCard: result.drawnCard });

    navigate("booster", result);
  } catch (err) {
    console.error("Erreur premier booster :", err);
    navigate("dashboard"); // Fallback
  }
}

/**
 * Ouvre un booster depuis le dashboard.
 */
async function handleOpenBooster() {
  const btn = document.getElementById("btn-open-booster");
  btn.disabled = true;
  btn.textContent = "Ouverture...";

  try {
    const result = await openBooster();

    localStorage.setItem("ac_user", JSON.stringify(result.user));
    setState({ currentUser: result.user, lastDrawnCard: result.drawnCard });

    navigate("booster", result);
  } catch (err) {
    showError(err.message);
    btn.disabled = false;
    btn.textContent = "📦 Ouvrir un Booster";
  }
}

/**
 * Affiche l'inventaire du joueur.
 */
async function handleViewInventory() {
  try {
    const inventoryData = await getInventory();
    navigate("inventory", inventoryData);
  } catch (err) {
    showError(err.message);
  }
}

/**
 * Déconnecte le joueur.
 */
function handleLogout() {
  logout();
  localStorage.removeItem("ac_user");
  setState({ currentUser: null });
  navigate("auth");
}

// =========================================================
// DÉMARRAGE
// =========================================================

init();
