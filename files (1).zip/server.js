/**
 * SERVER.JS — Point d'entrée du backend
 *
 * Architecture :
 *   Express  → API REST (auth, booster, progression)
 *   Socket.IO → Multijoueur temps réel (implémenté à l'étape 3)
 *
 * Démarrage : node server.js  /  nodemon server.js
 */

const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");

// --- Initialisation ---
const app = express();
const httpServer = http.createServer(app);

// Socket.IO attaché au même serveur HTTP (prêt pour l'étape 3)
const io = new Server(httpServer, {
  cors: {
    origin: "http://localhost:5173", // Port par défaut de Vite
    methods: ["GET", "POST"],
  },
});

// --- Middlewares globaux ---
app.use(cors({ origin: "http://localhost:5173" }));
app.use(express.json());

// Logger simple pour le dev
app.use((req, _res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// --- Routes REST ---
const authRoutes = require("./routes/auth");
const boosterRoutes = require("./routes/booster");

app.use("/api/auth", authRoutes);
app.use("/api/booster", boosterRoutes);

// Route de santé — utile pour vérifier que le serveur tourne
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// --- Socket.IO (placeholder étape 3) ---
io.on("connection", (socket) => {
  console.log(`[SOCKET] Client connecté : ${socket.id}`);

  socket.on("disconnect", () => {
    console.log(`[SOCKET] Client déconnecté : ${socket.id}`);
  });

  // Les événements de combat seront ajoutés à l'étape 3
});

// --- Démarrage ---
const PORT = process.env.PORT || 3000;
httpServer.listen(PORT, () => {
  console.log(`\n🌿 AnimalCards Server démarré sur http://localhost:${PORT}`);
  console.log(`   API REST    → http://localhost:${PORT}/api`);
  console.log(`   Socket.IO   → ws://localhost:${PORT}`);
  console.log(`   Health check → http://localhost:${PORT}/api/health\n`);
});

module.exports = { app, io }; // Export pour les tests
